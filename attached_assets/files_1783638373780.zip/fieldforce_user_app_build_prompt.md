# Build Prompt — "FieldForce Live" User Mobile App (Android / iOS / Huawei)

> Hand this to a **Flutter-capable builder or mobile developer**. It specifies the field-employee mobile app that pairs with the Node.js + Express admin backend already built ("FieldForce Live Master Panel"). It talks to that backend's REST + WebSocket API. **Note:** native mobile apps cannot be built or published from Replit — use Flutter (recommended) so a single codebase ships to Google Play, Apple App Store, and Huawei AppGallery.

---

## 1. Objective

A lightweight, battery-aware field-force app that a company employee installs via a magic link, signs into, and uses to run their day: see their prioritized list of customer visits and route, clock their shift (attendance), mark idle/busy time at each stop, raise an emergency, and close each visit with a disposition + notes. The app continuously (push-based) streams location and status to the admin backend so the admin sees everything live.

---

## 2. Platforms, tooling & publishing

- **Framework:** **Flutter** (single codebase → Android, iOS, Huawei).
- **Critical Huawei note:** Huawei phones (EMUI/HarmonyOS, post-2019) usually have **no Google Mobile Services (GMS)**. Google Maps SDK and Firebase Cloud Messaging will not work on them. Build a **capability abstraction** that detects GMS vs HMS at runtime and uses:
  - **Maps:** Google Maps (`google_maps_flutter`) on GMS devices; **Huawei Map Kit** on HMS-only devices.
  - **Push:** FCM on GMS/Android, **APNs** on iOS, **HMS Push Kit** on Huawei.
  - **Location:** platform location services on all; use a foreground service on Android for background tracking.
- **Publish to:** Google Play, Apple App Store, Huawei AppGallery. Provide separate build flavors (`gms`, `hms`) if needed, correct signing configs, and the required **data-safety / privacy declarations** for continuous + background location on each store (Google Play background-location justification, Apple "Always" location purpose strings, Huawei AppGallery privacy declaration).
- **State mgmt:** Riverpod or Bloc. **Secure storage:** `flutter_secure_storage` for the auth/device token. **HTTP:** Dio. **WebSocket** for live status where available, HTTP fallback otherwise.

---

## 3. Onboarding via magic link

1. Admin creates the user in the console and sends a **magic link** over **WhatsApp / SMS / email**.
2. The link opens a smart landing page (`/onboard/:token`) that detects the device and routes to the **correct store** — Apple App Store (iOS), Google Play (Android w/ GMS), **Huawei AppGallery** (Huawei/HMS) — with manual buttons for all three as fallback.
3. The landing page presents a **location-tracking consent** screen; the user must explicitly agree before the account is activated (`POST /api/onboarding/:token/consent`).
4. After install and first launch, the app **re-confirms consent in-app** and requests OS permissions (see §5), then deep-links/carries the onboarding token so the user lands on sign-in already associated with their account.

---

## 4. Permissions & consent (first launch)

- Show a plain-language consent screen explaining that the employer tracks location **during work** for field-force management, with a link to the privacy policy.
- Request: **location (foreground + background/Always)**, notifications, and (Android) disable-battery-optimization guidance so background tracking survives.
- Do not proceed to tracking until consent + permission are granted; store `consentGivenAt`.

---

## 5. Authentication (user's choice of method)

Login screen must let the user **choose how they sign in**:
- **Identifier:** username **or** email **or** phone number (segmented selector; the app accepts any of the three).
- **Credential:** **password** **or** **OTP** (toggle). OTP is sent to email/phone via the backend.
- Endpoints: `POST /api/user/auth/login` (identifier + password), `POST /api/user/auth/otp/request` and `POST /api/user/auth/otp/verify` (identifier + code). On success, store a device token securely and register the push token (FCM/APNs/HMS).
- **This requires the admin "Create User" form to capture `username` in addition to email and phone** — see §11.

---

## 6. Home tab — map, route & shift controls

Top of screen = a **map** (Google or Huawei per device) showing:
- **Pins** at every customer location the user must visit **today**, colored by priority (P1 red, P2 amber, P3 grey) and numbered by planned sequence.
- The **route from the user's current position** across the stops (the priority-ordered plan pushed from admin), drawn as a polyline.
- The user's own live position.

Below the map, **four controls** with exact behavior:

**(1) Login (Start Shift)** — distinct from app sign-in. Pressing it **starts the shift attendance timer**, which is mirrored live in the admin app. This timer's record **is the user's attendance**. Sends `POST /api/ingest/session { event: "SHIFT_LOGIN", lat, lng, at }`. Display running shift duration.

**(2) Idle / Busy toggle** — starts **blue, labeled "Idle"**. This is a per-location work timer:
- **First press (Idle → Busy):** starts a location work-timer, button turns **red, labeled "Busy"**. Immediately sends status to admin: `POST /api/user/status { status: "BUSY", visitStopId, lat, lng, at }`. Admin then shows this user as **Busy** with a live "busy since HH:MM" counter and the lat/long.
- **Second press (Busy → Idle):** stops the timer, button back to **blue "Idle"**. Sends `{ status: "IDLE", visitStopId, lat, lng, at }` plus the elapsed time-at-location. Admin flips the user's live status back to Idle.
- Repeats at each location; each Busy→Idle cycle logs time spent at that stop with its lat/long.

**(3) Logout (End Shift)** — ends the shift; this timestamp is the user's **logout time**. Sends `POST /api/ingest/session { event: "SHIFT_LOGOUT", lat, lng, at }`, stops the attendance timer.

**(4) Emergency** — press to **raise an emergency**: the user's marker **blinks** on the admin dashboard so the admin sees a problem. Sends `POST /api/user/emergency { active: true, lat, lng }`. **Pressing again stops the blinking** (`{ active: false }`). Make this button visually distinct and hard to trigger by accident (e.g. long-press or confirm).

---

## 7. Visits tab — prioritized list, proximity, dispositions

A per-user **list of today's visit stops**, pushed from the admin console (`GET /api/user/dayplan?date=YYYY-MM-DD`), shown **in priority order (P1 → P2 → P3, then planned sequence)**. Each row shows: customer code, exact **address**, **contact name**, **contact phone number(s)** (tap to call), priority chip, and status.

**Proximity highlighting:** using the live location vs each stop's geo-tag, when the user is **within 25 m** of a customer location, **bold-highlight** that row (and surface it to the top / pulse it). **Only the highlighted (in-range) entry is selectable** for action — the user cannot disposition a stop they aren't physically at.

**Selecting the highlighted entry** opens an action sheet to:
- **Select a disposition** from a system-wide list configured by the admin (`GET /api/config/dispositions`), e.g. *Person not available*, *Premises locked*, *Work completed partially* — these are **admin-configurable**, not hard-coded.
- **Add notes**, limited to **250 characters** (enforce with a live counter).
- **Save.**

**On save** (`POST /api/user/visit/:visitStopId/disposition { dispositionId, notes, reachedAt, startedAt, closedAt, lat, lng }`), the stop's status becomes **Closed** and the row displays:
- **Time reached** — first moment the user came within 25 m (auto-captured),
- **Time started** — when the user pressed Idle→Busy at this stop (work start),
- **Time closed** — when the disposition was saved.

**Progress bar:** a bar at the top of the tab showing visits **completed vs total**, rendered as a **green→red gradient** that fills toward green as visits complete. Show the count as e.g. **`2/10`** (2 completed of 10 total; label it clearly). Completed stops render in one color (e.g. green), pending stops in another (e.g. red/grey), so the list is scannable at a glance.

---

## 8. Continuous (push-based) tracking

- The app **continuously transmits movement** to the backend via `POST /api/ingest/location { lat, lng, accuracyM, batteryLevel, speed, recordedAt }` on a cadence (e.g. every 5–15 s while on shift; back off when stationary to save battery).
- **Offline resilience:** queue pings locally when offline and **batch-upload** (array body) on reconnect.
- Android background reliability via a **foreground service** with a persistent "on shift" notification; iOS via Always-location + significant-change/region monitoring; Huawei via HMS Location background mode.
- Keep the admin's live map current; also feed §6 status changes and §7 events in real time.

---

## 9. Data the app captures (aligns to backend models)

Shift sessions (login/logout → attendance), status changes (idle/busy with visitStopId, lat/long, timestamps, dwell duration), emergency toggles, location pings, and per-visit closures (disposition, notes ≤250, reached/started/closed timestamps, closing lat/long). All keyed to the authenticated user and their `visitStopId`s.

---

## 10. Backend API contract (this app consumes)

Existing (from admin build): `POST /api/ingest/location`, `POST /api/ingest/session`, `POST /api/onboarding/:token/consent`, `GET /api/user/dayplan`.
**Add / confirm these on the Node.js + Express backend:**
- `POST /api/user/auth/login`, `POST /api/user/auth/otp/request`, `POST /api/user/auth/otp/verify` — multi-identifier (username/email/phone) + password-or-OTP.
- `POST /api/user/status` — `{ status: "IDLE"|"BUSY", visitStopId, lat, lng, at }` → drives admin live Busy/Idle + since-timer.
- `POST /api/user/emergency` — `{ active: bool, lat, lng }` → drives admin blink.
- `GET /api/config/dispositions` — system-wide disposition list.
- `POST /api/user/visit/:visitStopId/disposition` — `{ dispositionId, notes, reachedAt, startedAt, closedAt, lat, lng }` → closes the stop.
- `POST /api/user/push-token` — register FCM/APNs/HMS token for the emergency/day-plan pushes.

---

## 11. Required admin-side / backend additions (keep the two builds in sync)

The admin panel & Node.js + Express backend must be extended to support this app:
1. **User model:** add **`username`** (unique per customer) to the Create-User form and auth. Login identifier can be username, email, or phone.
2. **VisitStop:** add **`contactName`** and **`contactPhone`** fields (shown in the app's list), and store per-visit **`reachedAt`, `startedAt`, `closedAt`, `dispositionId`, `notes`**.
3. **Disposition (new entity):** `id, customerId, label, active, sortOrder` — admin CRUD screen to configure the system-wide disposition list (Person not available / Premises locked / Work completed partially / …).
4. **Live status on admin map:** render each user as **Idle / Busy** (with "busy since HH:MM") and make the marker **blink on Emergency**; reflect status the instant the app posts it.
5. **Attendance report:** derive from `SHIFT_LOGIN`/`SHIFT_LOGOUT` sessions per user per day (start, end, total hours) and expose an admin report view + CSV export.
6. **Per-user visit progress:** show completed/total and each stop's reached/started/closed times and disposition/notes on the user detail page.

---

## 12. UI / UX

- Clean, high-contrast, field-friendly (usable outdoors, one-handed, large tap targets).
- Two bottom tabs: **Home** (map + shift controls) and **Visits** (list + progress + dispositions).
- Clear color language: Idle = blue, Busy = red, Emergency = distinct alert style; completed = green, pending = red/grey; priority chips P1/P2/P3.
- Localize timestamps to the user's timezone (default Asia/Kolkata, configurable).
- Persistent "On shift / Off shift" indicator.

---

## 13. Security & privacy

- Store tokens in secure storage; all API calls over HTTPS; scope every request to the authenticated user.
- Continuous location tracking is **consent-gated** and should be **bounded to shift hours** where possible (start on Shift Login, ease off after Logout) to respect the employee and meet store background-location policies.
- Provide an in-app privacy notice and the ability to view what's being shared.
- Comply with each store's data-safety declarations for location.

---

## 14. Deliverables & acceptance criteria

Done means:
1. Single Flutter codebase builds and is publishable to **Google Play, App Store, and Huawei AppGallery**, with GMS/HMS abstraction for maps + push.
2. Magic link routes to the right store per device and captures location consent; app re-confirms consent + permissions on first launch.
3. Sign-in works with **username / email / phone**, and with **password or OTP**, user's choice.
4. Home shows the map with today's priority pins + route and the four controls behaving exactly as specified: **Login** starts the attendance timer (mirrored in admin); **Idle/Busy** toggles blue↔red and streams status + time-at-location; **Logout** ends the shift; **Emergency** blinks the admin marker and toggles off.
5. Visits tab lists stops in priority order with address + contact name/phone; the in-range (**≤25 m**) stop bolds and becomes the only selectable one; disposition (admin-configured) + 250-char notes save and close the stop, recording **time reached / started / closed**.
6. Progress bar shows completed/total (e.g. `2/10`) with green→red gradient; completed vs pending rows are color-differentiated.
7. App transmits movement continuously (push-based), batches offline, and keeps the admin live view current.
8. Backend gains the auth, status, emergency, disposition, and visit-closure endpoints; admin gains username, contacts, disposition config, live Busy/Idle + blink, and attendance reporting.

Provide a README covering build flavors (GMS/HMS), signing, store declarations, required backend endpoints, and environment config.
